var um_editor;

jQuery(window).load(function(){
	um_editor = tinymce.get('um_live_content');
});

jQuery(document).ready(function($){
	var public_selector = "";
	var debug_mode = false;
	
	$(window).keypress(function(e){
		if(e.keyCode == 96){
			debug_mode = !debug_mode ? true : false;
			if(debug_mode){
				$("#um_debug_on").show();
			}else{
				$("#um_debug_on").hide();
			}
		}
		if(e.keyCode == 27){
			hide_dialog();
		}
	});
	
	$(document).keyup(function(e) {
		if (e.keyCode == 27) {
			hide_dialog();
		}
	});
	
	$("a#um_live_save").live("click",function(e){
		e.preventDefault();
		var p_id = $("#um_p_id").val();
		//var markup = $("#um_live_content").val();
		var markup = um_editor.getContent();
		var title = $("#um_title").val();
		var query_string = {
			action : "um_save_html",
			um_page_id : p_id,
			um_html : markup,
			um_selector : public_selector,
			um_title : title
		};
		$.post(liveeditajaxurl,query_string,function(data){
			window.location.reload();
		});
		hide_dialog();
	});

	$("*").live("click",function(e){
		if(!debug_mode){
			return true;
		}
		var selector = $(this).parents()
                .map(function() { return this.tagName != "HTML" ? this.tagName : ""; })
                .get().reverse().join(" ");
			selector = selector.trim();
            if (selector) {
                selector += " "+ $(this)[0].nodeName;
            }

            var id = $(this).attr("id");
            if (id) {
                selector += "#"+ id;
            }

            var classNames = $(this).attr("class");
            if (classNames) {
                selector += "." + $.trim(classNames).replace(/\s/gi, ".");
            }
			
			if(!$("#um_overlay").is(":visible")){
				//tb_show("","#TB_inline?width=600&height=550&inlineId=um_edit_screen");
				show_dialog();
				//$("#um_live_content").val($(this).html().trim());
				if(typeof um_editor !== 'undefined'){
					um_editor.setContent($(this).html().trim());
				}
				public_selector = selector;
			}
            return false;
	});
	
	function show_dialog(){
		$("#um_overlay").show();
	}
	
	function hide_dialog(){
		$("#um_overlay").hide();
	}
	
	$("body").mouseover(function(e){
		if(!debug_mode){
			box.hide();
			return false;
		}
		var el = $(e.target);
		var offset = el.offset();
		if(!$("#TB_window").is(":visible")){
			box.render(el.outerWidth(), el.outerHeight(), offset.left, offset.top);
		}else{
			box.hide();
		}
	});
	
	var box = new Overlay();

	function Overlay(width, height, left, top) {

		this.width = this.height = this.left = this.top = 0;

		// outer parent
		var outer = $("<div class='um_outer' />").appendTo("body");

		// red lines (boxes)
		var topbox    = $("<div />").css("height", 1).appendTo(outer);
		var bottombox = $("<div />").css("height", 1).appendTo(outer);  
		var leftbox   = $("<div />").css("width",  1).appendTo(outer);
		var rightbox  = $("<div />").css("width",  1).appendTo(outer);

		// don't count it as a real element
		outer.mouseover(function(){ 
			outer.hide(); 
		});    

		/**
		 * Public interface
		 */

		this.resize = function resize(width, height, left, top) {
		  if (width != null)
			this.width = width;
		  if (height != null)
			this.height = height;
		  if (left != null)
			this.left = left;
		  if (top != null)
			this.top = top;      
		};

		this.show = function show() {
		   outer.show();
		};

		this.hide = function hide() {
		   outer.hide();
		};     

		this.render = function render(width, height, left, top) {

			this.resize(width, height, left, top);

			topbox.css({
			  top:   this.top,
			  left:  this.left,
			  width: this.width
			});
			bottombox.css({
			  top:   this.top + this.height - 1,
			  left:  this.left,
			  width: this.width
			});
			leftbox.css({
			  top:    this.top, 
			  left:   this.left, 
			  height: this.height
			});
			rightbox.css({
			  top:    this.top, 
			  left:   this.left + this.width - 1, 
			  height: this.height  
			});

			this.show();
		};      

		// initial rendering [optional]
		// this.render(width, height, left, top);
	}
	
	$("body").append("<style>.um_outer { display:none; }.um_outer div { position:absolute; background:rgb(255,0,0); z-index:65000; }</style>");
	
});